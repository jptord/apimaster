{
    id: 2,
    label: 'pagoforma',
    link : '/pagoforma',
    icon: 'bx-home-circle',
},