{
    id: 2,
    label: 'fondos',
    link : '/fondos',
    icon: 'bx-home-circle',
},