{
    id: 2,
    label: 'tipoentidad',
    link : '/tipoentidad',
    icon: 'bx-home-circle',
},