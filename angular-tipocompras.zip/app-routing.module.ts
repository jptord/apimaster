// ** AGREGAR ESTA RUTA DESPUES DE const routes: Routes = [
{ path: 'tipocompras', loadChildren: () => import('./tipocompras/tipocompras.module').then(m => m.TipocomprasModule  )},